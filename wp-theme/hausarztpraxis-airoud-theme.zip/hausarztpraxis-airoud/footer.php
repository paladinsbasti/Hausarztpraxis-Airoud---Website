</main>
<footer class="site-footer">
  <div class="footer-inner">
    <p>&copy; <?php echo date('Y'); ?> Hausarztpraxis Airoud</p>
    <p>
      <a href="<?php echo esc_url( home_url('/impressum/') ); ?>">Impressum</a> |
      <a href="<?php echo esc_url( home_url('/datenschutz/') ); ?>">Datenschutz</a>
    </p>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
